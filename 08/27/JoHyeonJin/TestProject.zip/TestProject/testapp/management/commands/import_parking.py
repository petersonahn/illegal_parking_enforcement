import csv
from django.core.management.base import BaseCommand
from testapp.models import ParkingLot
from pathlib import Path

class Command(BaseCommand):
    help = 'Import parking data from CSV file'

    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str)

    def handle(self, *args, **options):
        csv_path = Path(options['csv_file'])
        if not csv_path.exists():
            self.stdout.write(self.style.ERROR('CSV 파일이 존재하지 않습니다.'))
            return

        with open(csv_path, newline='', encoding='utf-8-sig') as csvfile:
            reader = csv.DictReader(csvfile)

            for row in reader:
                ParkingLot.objects.create(
                    number=int(row['주차장번호']),
                    pkplcId=row['주차장아이디'] or None,
                    name=row['주차장명'],
                    category=row['주차장구분'],
                    type=row['주차장유형'],
                    road_address=row['소재지도로명주소'] or None,
                    jibun_address=row['소재지지번주소'] or None,
                    capacity=int(row['주차구획수']),
                    operating_days=row['운영요일'],
                    weekday_start=row['평일운영시작시각'],
                    weekday_end=row['평일운영종료시각'],
                    saturday_start=row['토요일운영시작시각'],
                    saturday_end=row['토요일운영종료시각'],
                    holiday_start=row['공휴일운영시작시각'],
                    holiday_end=row['공휴일운영종료시각'],
                    fee_type=row['요금정보'],
                    base_time=int(row['주차기본시간'] or 0),
                    base_fee=int(row['주차기본요금'] or 0),
                    unit_time=int(row['추가단위시간'] or 0),
                    unit_fee=int(row['추가단위요금'] or 0),
                    daily_pass_time=int(row['1일주차권요금적용시간'] or 0) if row['1일주차권요금적용시간'] else None,
                    daily_pass_fee=int(row['1일주차권요금'] or 0) if row['1일주차권요금'] else None,
                    monthly_pass_fee=int(row['월정기권요금'] or 0) if row['월정기권요금'] else None,
                    phone_number=row['전화번호'],
                    latitude=float(row['위도']),
                    longitude=float(row['경도']),
                    is_disabled_parking=(row['장애인전용주차구역보유여부'].strip().upper() == 'Y'),
                )

            self.stdout.write(self.style.SUCCESS('데이터 삽입 완료'))
