from django.contrib import admin
from .models import ParkingLot, TrafficCamera, IllegalParkingRecord

@admin.register(ParkingLot)
class ParkingLotAdmin(admin.ModelAdmin):
    def get_list_display(self, request):
        return [field.name for field in self.model._meta.fields]

@admin.register(TrafficCamera)
class TrafficCameraAdmin(admin.ModelAdmin):
    def get_list_display(self, request):
        return [field.name for field in self.model._meta.fields]

@admin.register(IllegalParkingRecord)
class IllegalParkingRecordAdmin(admin.ModelAdmin):
    def get_list_display(self, request):
        return [field.name for field in self.model._meta.fields]