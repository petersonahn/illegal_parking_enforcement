from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('api/parking-lots/', views.parking_lot_list, name='parking-lot-list'),
]
