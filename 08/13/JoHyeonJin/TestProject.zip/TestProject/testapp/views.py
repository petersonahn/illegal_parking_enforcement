from django.shortcuts import render
from django.http import JsonResponse
from .models import ParkingLot  # ✅ 모델 import

# HTML 페이지 렌더링
def main(request):
    return render(request, 'main.html')

# ✅ 주차장 데이터 JSON 반환 API
def parking_lot_list(request):
    data = list(ParkingLot.objects.values('name', 'latitude', 'longitude'))
    return JsonResponse(data, safe=False)
