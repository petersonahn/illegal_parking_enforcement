from django.shortcuts import render, redirect
from django.contrib.auth import authenticate,   login, logout, update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
from .models import CustomUser
from .forms import CustomUserCreationForm
from django.http import JsonResponse
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.core.mail import send_mail
from django.conf import settings
from django.utils.encoding import force_str
from django.utils.http import urlsafe_base64_decode


def signup_view(request):
    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']

            # 사용자 생성
            user = form.save(commit=False)
            user.first_name = form.cleaned_data['full_name']
            user.phone_number = form.cleaned_data['phone_number']
            user.car_number = form.cleaned_data['car_number']
            user.email = email
            user.save()

            # 로그인 처리
            login(request, user)
            return JsonResponse({'success': True, 'message': '회원가입 완료! 바로 로그인되었습니다.'})

        else:
            # form validation 실패 메시지
            errors = {field: [str(e) for e in error_list] for field, error_list in form.errors.items()}
            return JsonResponse({'success': False, 'errors': errors})

    return JsonResponse({'success': False, 'errors': ['잘못된 요청입니다.']})


# 로그인
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'{username}님, 환영합니다!')
            return redirect('/')
        else:
            messages.error(request, '아이디 또는 비밀번호가 틀립니다.')
            return redirect('/')
    return redirect('/')


# 로그아웃
def logout_view(request):
    logout(request)
    messages.success(request, '성공적으로 로그아웃되었습니다.')
    return redirect('/')


# 유저 상세 페이지
def update_profile(request):
    user = request.user
    if request.method == 'POST':
        user.email = request.POST.get('email')
        user.phone_number = request.POST.get('phone_number')
        user.car_number = request.POST.get('car_number')
        user.save()
        # 메시지 추가 가능
        return redirect('/')  # 수정 후 이동할 페이지
    return render(request, 'accounts/profile_modal.html', {'user': user})

# 회원 탈퇴
def delete_account(request):
    if request.method == 'POST':
        request.user.delete()
        messages.success(request, '회원탈퇴가 완료되었습니다.')
        return redirect('main')  # 메인 페이지로 이동
    messages.error(request, '잘못된 접근입니다.')
    return redirect('main')


# 비밀번호 변경
def change_password(request):
    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            return JsonResponse({'success': True, 'messages': ['비밀번호가 성공적으로 변경되었습니다.']})
        else:
            errors = []
            for e in form.errors.values():
                errors.extend(e)
            return JsonResponse({'success': False, 'messages': errors})
    return JsonResponse({'success': False, 'messages': ['잘못된 접근입니다.']})

# 아이디 찾기 filter()
def find_id(request):
    if request.method == "POST" and request.headers.get("x-requested-with") == "XMLHttpRequest":
        name = request.POST.get("name")
        email = request.POST.get("email")

        users = CustomUser.objects.filter(full_name=name, email=email)
        if users.exists():
            usernames = [user.username for user in users]
            return JsonResponse({"success": True, "usernames": usernames})
        else:
            return JsonResponse({"success": False, "message": "해당 정보로 등록된 계정이 없습니다."})

    return JsonResponse({"success": False, "message": "잘못된 요청입니다."})

# 비밀번호 재설정 요청 (이메일 입력)
def reset_password_request(request):
    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        email = request.POST.get('email')
        try:
            user = CustomUser.objects.get(email=email)
            token = default_token_generator.make_token(user)
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            reset_link = request.build_absolute_uri(f'/accounts/reset/{uid}/{token}/')

            send_mail(
                '비밀번호 재설정 안내',
                f'비밀번호 재설정을 위해 링크를 클릭하세요: {reset_link}',
                settings.DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False,
            )
            return JsonResponse({'success': True, 'message': '비밀번호 재설정 링크가 이메일로 발송되었습니다.'})
        except CustomUser.DoesNotExist:
            return JsonResponse({'success': False, 'message': '등록된 이메일이 없습니다.'})

    return JsonResponse({'success': False, 'message': '잘못된 요청입니다.'})

# 실제 비밀번호 재설정 페이지



def reset_password_confirm(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = CustomUser.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, CustomUser.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        if request.method == 'POST':
            form = SetPasswordForm(user, request.POST)
            if form.is_valid():
                form.save()
                return redirect('accounts:login')
        else:
            form = SetPasswordForm(user)
        return render(request, 'accounts/reset_password_confirm.html', {'form': form})
    else:
        return render(request, 'accounts/reset_password_invalid.html')
