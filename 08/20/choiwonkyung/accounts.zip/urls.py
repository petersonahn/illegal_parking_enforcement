from django.urls import path
from . import views

app_name = 'accounts'


urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/update/', views.update_profile, name='update_profile'),
    path('delete/', views.delete_account, name='delete_account'),
    path('change-password/', views.change_password, name='change_password'),
    path('profile/', views.update_profile, name='profile'),
    path("find-id/", views.find_id, name="find_id"),
    path('reset/', views.reset_password_request, name='reset_password_request'),
    path('reset/<uidb64>/<token>/', views.reset_password_confirm, name='reset_password_confirm'),
]
