from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import CustomUser
from .forms import CustomUserCreationForm



def signup_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']

            # 이미 존재하는 사용자 체크
            if CustomUser.objects.filter(username=username).exists():
                messages.error(request, '이미 존재하는 사용자입니다.')
                return redirect('/')

            # 사용자 생성
            user = form.save(commit=False)
            user.first_name = form.cleaned_data['full_name']
            user.phone_number = form.cleaned_data['phone_number']
            user.car_number = form.cleaned_data['car_number']
            user.save()

            # 로그인 처리
            login(request, user)
            messages.success(request, '회원가입이 완료되었습니다!')
        else:
            messages.error(request, '회원가입에 실패했습니다. 입력 내용을 확인해주세요.')

    return redirect('/')  # 항상 메인 페이지로 이동


# 로그인
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'{username}님, 환영합니다!')
            return redirect('/')
        else:
            messages.error(request, '아이디 또는 비밀번호가 틀립니다.')
            return redirect('/')
    return redirect('/')


# 로그아웃
def logout_view(request):
    logout(request)
    messages.success(request, '성공적으로 로그아웃되었습니다.')
    return redirect('/')


# 유저 상세 페이지
def profile_view(request):
    return render(request, 'accounts/profile_view.html')