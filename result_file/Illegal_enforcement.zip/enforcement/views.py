from django.db.models import Count
from django.utils import timezone

from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from .models import ParkingLot, TrafficCamera, IllegalParkingRecord

import requests, json
import xml.etree.ElementTree as ET

# HTML 페이지 렌더링
def main(request):
    return render(request, 'main.html')

def parking_lot_list(request):
    data = list(ParkingLot.objects.values(
        'number', 'pkplcId', 'category', 'fee_type', 'capacity',
        'road_address', 'jibun_address', 'phone_number',
        'name', 'latitude', 'longitude'
    ))
    return JsonResponse(data, safe=False)

def traffic_camera_list(request):
    data = list(TrafficCamera.objects.values(
        'camera_id', 'latitude', 'longitude', 'address'
    ))
    return JsonResponse(data, safe=False)

def realtime_parking_data(request):
    service_key = "e7e6289f86fbda761d8456a8513b6f635783aa11"
    lae_id = "31100"
    url = "https://openapigits.gg.go.kr/api/rest/getParkingPlaceAvailabilityInfoList"

    params = {
        "serviceKey": service_key,
        "laeId": lae_id
    }

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()

        root = ET.fromstring(response.content)
        items = root.findall(".//itemList")

        result = []
        for item in items:
            result.append({
                "pkplcId": item.findtext("pkplcId"),
                "pklotCnt": int(item.findtext("pklotCnt")),
                "avblPklotCnt": int(item.findtext("avblPklotCnt")),
            })

        return JsonResponse(result, safe=False)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

def parking_detail(request, number):
    lot = get_object_or_404(ParkingLot, number=number)
    return render(request, 'parking_detail.html', {'lot': lot})

@csrf_exempt
def illegal_parking_record(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            gu = data.get('gu', '알 수 없음')
            dong = data.get('dong', '알 수 없음')
            district = f"{gu} {dong}"

            record = IllegalParkingRecord.objects.create(
                district=district
            )
            return JsonResponse({'id': record.id}, status=201)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'POST 요청만 허용'}, status=405)

def illegal_parking_stats(request):
    period = request.GET.get('period', 'week')
    gu = request.GET.get('gu', None)  # 여기 추가

    now = timezone.now()
    if period == 'week':
        start = now - timezone.timedelta(days=7)
    elif period == 'month':
        start = now - timezone.timedelta(days=30)
    elif period == 'year':
        start = now - timezone.timedelta(days=365)
    else:
        start = None  # 전체

    qs = IllegalParkingRecord.objects.all()
    if start:
        qs = qs.filter(timestamp__gte=start)

    if gu and gu != 'all':            # 선택한 구가 있을 때만 필터
        qs = qs.filter(district__startswith=gu)

    # 날짜별, 동별 집계
    stats = qs.values('district').annotate(count=Count('id')).order_by('-count')

    return JsonResponse(list(stats), safe=False)

def illegal_parking_stats_page(request):
    if not request.user.is_authenticated:
        return HttpResponse("""
            <script>
                alert('로그인이 필요한 서비스입니다.');
                window.history.back();
            </script>
        """)
    return render(request, 'illegal_parking_stats.html')

def district_list(request):
    districts = (IllegalParkingRecord.objects
                   .exclude(district__isnull=True)
                   .exclude(district='')
                   .values_list('district', flat=True)
                   .distinct()
                   .order_by('district'))
    return JsonResponse(list(districts), safe=False)

def section_map(request):
    return render(request, 'section.html')
