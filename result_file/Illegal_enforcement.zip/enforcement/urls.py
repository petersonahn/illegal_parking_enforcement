from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('api/parking-lots/', views.parking_lot_list, name='parking-lot-list'),
    path('api/traffic-cameras/', views.traffic_camera_list, name='traffic_camera_list'),
    path('api/realtime_parking/', views.realtime_parking_data, name='realtime_parking'),
    path('parking/<int:number>/', views.parking_detail, name='parkinglot-detail'),
    path('api/illegal_parking/', views.illegal_parking_record, name='illegal-parking'),
    path('api/illegal_parking/stats/', views.illegal_parking_stats, name='illegal-parking-stats'),
    path('api/illegal_parking/districts/', views.district_list, name='illegal-parking-districts'),
    path('illegal_parking_stats/', views.illegal_parking_stats_page, name='illegal-parking-stats-page'),
    path('accounts/', include('accounts.urls')),
    path('section/', views.section_map, name='section-map'),
]
