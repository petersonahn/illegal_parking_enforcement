from django.db import models
from django.urls import reverse

class ParkingLot(models.Model):
    number = models.IntegerField()  # 주차장번호
    name = models.CharField(max_length=100)  # 주차장명
    category = models.CharField(max_length=20)  # 주차장구분 (공영 등)
    type = models.CharField(max_length=20)  # 주차장유형 (노외, 부설 등)
    road_address = models.CharField(max_length=200, null=True, blank=True)  # 소재지도로명주소
    jibun_address = models.CharField(max_length=200, null=True, blank=True)  # 소재지지번주소
    capacity = models.IntegerField()  # 주차구획수

    operating_days = models.CharField(max_length=50)  # 운영요일

    weekday_start = models.CharField(max_length=10)  # 평일운영시작시각
    weekday_end = models.CharField(max_length=10)  # 평일운영종료시각
    saturday_start = models.CharField(max_length=10)  # 토요일운영시작시각
    saturday_end = models.CharField(max_length=10)  # 토요일운영종료시각
    holiday_start = models.CharField(max_length=10)  # 공휴일운영시작시각
    holiday_end = models.CharField(max_length=10)  # 공휴일운영종료시각

    fee_type = models.CharField(max_length=20)  # 요금정보 (무료/유료/혼합 등)
    base_time = models.IntegerField(default=0)  # 주차기본시간 (분)
    base_fee = models.IntegerField(default=0)  # 주차기본요금
    unit_time = models.IntegerField(default=0)  # 추가단위시간
    unit_fee = models.IntegerField(default=0)  # 추가단위요금

    daily_pass_time = models.IntegerField(null=True, blank=True)  # 1일주차권요금적용시간
    daily_pass_fee = models.IntegerField(null=True, blank=True)  # 1일주차권요금
    monthly_pass_fee = models.IntegerField(null=True, blank=True)  # 월정기권요금

    phone_number = models.CharField(max_length=20)  # 전화번호
    latitude = models.FloatField()  # 위도
    longitude = models.FloatField()  # 경도

    is_disabled_parking = models.BooleanField()  # 장애인전용주차구역보유여부

    def __str__(self):
        return f"{self.name} ({self.number})"
