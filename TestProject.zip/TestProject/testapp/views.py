from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from .models import ParkingLot # ✅ 모델 import

# HTML 페이지 렌더링
def main(request):
    return render(request, 'main.html')

# ✅ 주차장 데이터 JSON 반환 API
def parking_lot_list(request):
    data = list(ParkingLot.objects.values('number', 'capacity', 'road_address', 'jibun_address', 'phone_number', 'name', 'latitude', 'longitude'))
    return JsonResponse(data, safe=False)

def parking_detail(request, number):
    lot = get_object_or_404(ParkingLot, number=number)
    return render(request, 'parking_detail.html', {'lot': lot})

